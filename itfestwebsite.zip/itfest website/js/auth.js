// Handle Sign Up
function handleSignUp(event) {
    event.preventDefault();
  
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    if (!username || !email || !password) {
      alert('All fields are required!');
      return;
    }
  
    // Save user data in localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const existingUser = users.find(user => user.email === email);
  
    if (existingUser) {
      alert('An account with this email already exists!');
      return;
    }
  
    users.push({ username, email, password });
    localStorage.setItem('users', JSON.stringify(users));
    alert('Account created successfully! You can now log in.');
    window.location.href = '/html/login.html';
  }
  
  // Handle Log In
  function handleLogIn(event) {
    event.preventDefault();
  
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    if (!email || !password) {
      alert('Both email and password are required!');
      return;
    }
  
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(user => user.email === email && user.password === password);
  
    if (!user) {
      alert('Invalid email or password!');
      return;
    }
  
    // Save the logged-in user in localStorage
    localStorage.setItem('loggedInUser', JSON.stringify(user));
    alert(`Welcome, ${user.username}!`);
    window.location.href = '/html/index.html'; // Redirect to homepage
  }
  
  // Check if User is Logged In
  function checkLoggedInUser() {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
  
    if (loggedInUser) {
      const welcomeMessage = document.getElementById('welcome-message');
      if (welcomeMessage) {
        welcomeMessage.textContent = `Welcome, ${loggedInUser.username}!`;
      }
  
      const authLinks = document.getElementById('auth-links');
      if (authLinks) {
        authLinks.innerHTML = `
          <button onclick="handleLogOut()">Log Out</button>
        `;
      }
    }
  }
  
  // Handle Log Out
  function handleLogOut() {
    localStorage.removeItem('loggedInUser');
    alert('You have been logged out.');
    window.location.href = '/html/login.html';
  }
  
  // Attach event listeners to forms
  document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.getElementById('signup-form');
    if (signupForm) signupForm.addEventListener('submit', handleSignUp);
  
    const loginForm = document.getElementById('login-form');
    if (loginForm) loginForm.addEventListener('submit', handleLogIn);
  
    checkLoggedInUser();
  });

  function handleLogIn(event) {
    event.preventDefault();
  
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    if (!email || !password) {
      alert('Both email and password are required!');
      return;
    }
  
    // Get the users array from localStorage
    const users = JSON.parse(localStorage.getItem('users')) || [];
  
    // Find a user with matching email and password
    const user = users.find(user => user.email === email && user.password === password);
  
    if (!user) {
      alert('Invalid email or password!');
      return;
    }
  
    // Save the logged-in user in localStorage
    localStorage.setItem('loggedInUser', JSON.stringify(user));
  
    alert(`Welcome, ${user.username}!`);
    window.location.href = '/html/private-cabinet.html'; // Redirect to Private Cabinet
  }
  function handleSignUp(event) {
    event.preventDefault();
  
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
  
    if (!username || !email || !password) {
      alert('All fields are required!');
      return;
    }
  
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const existingUser = users.find(user => user.email === email);
  
    if (existingUser) {
      alert('An account with this email already exists!');
      return;
    }
  
    users.push({ username, email, password });
    localStorage.setItem('users', JSON.stringify(users));
    alert('Account created successfully! You can now log in.');
    window.location.href = '/html/login.html';
  }
